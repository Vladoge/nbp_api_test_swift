//
//  ViewController.swift
//  KursWalut
//
//  Created by Vlad Koval on 24.06.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

